<?php
include 'ip.php';
header('Location: signin.php');
exit
?>
